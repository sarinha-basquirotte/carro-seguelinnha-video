
> Abrir essa página em [https://sarinha-basquirotte.github.io/carro-seguelinnha-video/](https://sarinha-basquirotte.github.io/carro-seguelinnha-video/)

## Usar como extensão

Este repositório pode ser adicionado como **extensão** no MakeCode.

* abrir [https://makecode.microbit.org/](https://makecode.microbit.org/)
* clique em **Novo Projeto**
* clique em **Extensões** em baixo do menu com ícone de engrenagem
* procure por **https://github.com/sarinha-basquirotte/carro-seguelinnha-video** e importe

## Editar este projeto ![Build status badge](https://github.com/sarinha-basquirotte/carro-seguelinnha-video/workflows/MakeCode/badge.svg)

Para editar este repositório no MakeCode.

* abrir [https://makecode.microbit.org/](https://makecode.microbit.org/)
* clique em **Importar** e depois clique em **Importar URL**
* cole **https://github.com/sarinha-basquirotte/carro-seguelinnha-video** e clique em importar

## Blocks preview

This image shows the blocks code from the last commit in master.
This image may take a few minutes to refresh.

![A rendered view of the blocks](https://github.com/sarinha-basquirotte/carro-seguelinnha-video/raw/master/.github/makecode/blocks.png)

#### Metadados (usados para pesquisa, renderização)

* for PXT/microbit
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
