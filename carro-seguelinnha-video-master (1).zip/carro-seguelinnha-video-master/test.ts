// testes vão aqui; isto não será compilado quando este pacote for usado como uma extensão.
